using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic;
using System.Threading;

class Server
{
    static TcpListener server;
    static List<ClientHandler> clients = new List<ClientHandler>();

    static void Main()
    {
        server = new TcpListener(IPAddress.Any, 8888);
        server.Start();
        Console.WriteLine("Server đang chạy...");

        while (true)
        {
            TcpClient client = server.AcceptTcpClient();
            ClientHandler handler = new ClientHandler(client);
            clients.Add(handler);
            new Thread(handler.Handle).Start();
        }
    }

    public static void Broadcast(string msg, string username)
    {
        foreach (var client in clients)
        {
            if (client.Username != username)
                client.Send(msg);
        }
    }

    public static void UpdateOnline()
    {
        string users = "ONLINE|" + string.Join(",", clients.ConvertAll(c => c.Username));
        foreach (var c in clients)
            c.Send(users);
    }

    class ClientHandler
    {
        TcpClient client;
        NetworkStream stream;
        public string Username;

        public ClientHandler(TcpClient c)
        {
            client = c;
            stream = c.GetStream();
        }

        public void Handle()
        {
            byte[] buffer = new byte[1024];

            try
            {
                int byteCount = stream.Read(buffer, 0, buffer.Length);
                Username = Encoding.UTF8.GetString(buffer, 0, byteCount);

                Console.WriteLine($"{Username} đã kết nối");
                UpdateOnline();

                while (true)
                {
                    byteCount = stream.Read(buffer, 0, buffer.Length);
                    string msg = Encoding.UTF8.GetString(buffer, 0, byteCount);

                    Broadcast(Username + "|" + msg, Username);
                }
            }
            catch
            {
                Console.WriteLine($"{Username} đã ngắt kết nối");
                clients.Remove(this);
                UpdateOnline();
                client.Close();
            }
        }

        public void Send(string msg)
        {
            byte[] data = Encoding.UTF8.GetBytes(msg);
            stream.Write(data, 0, data.Length);
        }
    }
}
